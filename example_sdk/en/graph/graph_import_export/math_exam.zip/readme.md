# math_exam
自动出题、答题、判题的数学练习系统，根据指定数量完成练习并生成HTML画报

## 流程图
```mermaid
graph TD
    Input(["start"]);
    Input(["start"]) --> node1["node1"];
    node1["node1"] --> node2["node2"];
    node2["node2"] --> node3{"node3"};
    node3{"node3"} --> node1["node1"];
    node3{"node3"} --> node4["node4"];
    node4["node4"] --> Output(["end"]);
```

## 节点列表
### node1
- 描述: 自动生成不重复的数学题目
- 使用模型: deepseek-chat

### node2
- 描述: 解答数学题目并给出详细过程
- 使用模型: deepseek-chat
- MCP服务器: math-calculator

### node3
- 描述: 检查题目和答案，统计完成进度并决定下一步
- 使用模型: deepseek-chat
- 最大决策次数: 5

### node4
- 描述: 生成完整的HTML练习画报
- 使用模型: deepseek-chat

## 使用的MCP服务器
### math-calculator
- 状态: 启用
- 超时: 60秒

## 使用的模型
### deepseek-chat
- 基础URL: https://gateway.ai.cloudflare.com/v1/79dc4e1b350a1ac66b63c0f6a9e0c7a6/deepseek-api/deepseek
- 模型标识符: deepseek-chat
