from fastmcp import FastMCP
import ast
import operator

# 创建安全的数学表达式计算环境
safe_operators = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.USub: operator.neg,
    ast.Pow: operator.pow
}

def safe_eval(expr: str) -> float:
    """
    安全地计算数学表达式

    Args:
        expr: 数学表达式字符串，如 "3+4*(2+2)"

    Returns:
        计算结果

    Raises:
        ValueError: 如果表达式无效或包含不安全的内容
    """
    try:
        # 解析表达式为AST
        tree = ast.parse(expr, mode='eval')

        # 定义安全的AST节点访问器
        def _eval(node):
            if isinstance(node, ast.Constant):
                return node.value
            elif isinstance(node, ast.BinOp):
                left = _eval(node.left)
                right = _eval(node.right)
                op_type = type(node.op)
                if op_type in safe_operators:
                    return safe_operators[op_type](left, right)
                else:
                    raise ValueError(f"不支持的运算符: {op_type}")
            elif isinstance(node, ast.UnaryOp):
                operand = _eval(node.operand)
                op_type = type(node.op)
                if op_type in safe_operators:
                    return safe_operators[op_type](operand)
                else:
                    raise ValueError(f"不支持的运算符: {op_type}")
            elif isinstance(node, ast.Name):
                raise ValueError("表达式不能包含变量")
            else:
                raise ValueError(f"不支持的表达式结构: {type(node)}")

        return _eval(tree.body)

    except SyntaxError:
        raise ValueError("表达式语法错误")
    except Exception as e:
        raise ValueError(f"计算错误: {str(e)}")

# 创建MCP服务器
mcp = FastMCP(
    name="MathCalculator",
    instructions="数学表达式计算工具，支持加减乘除和括号运算"
)

@mcp.tool()
def calculate_expression(expression: str) -> dict:
    """
    计算数学表达式

    支持基本的加减乘除运算和括号，如：3+4*(2+2)

    Args:
        expression: 数学表达式字符串

    Returns:
        dict: 包含计算结果或错误信息
    """
    try:
        # 去除空格
        expression = expression.replace(" ", "")

        # 验证表达式只包含数字和运算符
        valid_chars = set("0123456789+-*/().")
        if not all(char in valid_chars for char in expression):
            raise ValueError("表达式包含无效字符")

        # 计算表达式
        result = safe_eval(expression)

        return {
            "success": True,
            "result": result,
            "expression": expression
        }

    except ValueError as e:
        return {
            "success": False,
            "error": str(e),
            "expression": expression
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"计算过程中发生错误: {str(e)}",
            "expression": expression
        }

if __name__ == "__main__":
    mcp.run()