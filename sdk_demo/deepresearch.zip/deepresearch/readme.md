# deepresearch
深度分析用户问题，进行多轮智能检索，并最终生成可视化HTML网页的综合研究系统

## 流程图
```mermaid
graph TD
    Input(["start"]);
    Input(["start"]) --> question_analyzer["question_analyzer"];
    question_analyzer["question_analyzer"] --> todo_maker["todo_maker"];
    todo_maker["todo_maker"] --> search_executor["search_executor"];
    progress_checker{"progress_checker"} --> search_executor["search_executor"];
    search_executor["search_executor"] --> knowledge_manager["knowledge_manager"];
    knowledge_manager["knowledge_manager"] --> progress_checker{"progress_checker"};
    progress_checker{"progress_checker"} --> webpage_generator["webpage_generator"];
    webpage_generator["webpage_generator"] --> Output(["end"]);
```

## 节点列表
### question_analyzer
- 描述: 深度分析用户问题，识别核心主题、关键概念和研究维度，为后续研究提供全面的问题理解基础
- 使用模型: deepseek-chat

### todo_maker
- 描述: 基于问题分析结果制作系统性的研究计划，将复杂问题分解为具体可执行的研究任务并确定优先级
- 使用模型: deepseek-chat

### search_executor
- 描述: 执行信息检索任务，根据研究计划选择重要任务并使用搜索工具获取高质量的相关信息
- 使用模型: deepseek-chat
- MCP服务器: tavily-mcp

### knowledge_manager
- 描述: 管理和组织研究信息，将搜索结果结构化存储到知识图谱中，建立信息间的关联关系
- 使用模型: deepseek-chat
- MCP服务器: memory

### progress_checker
- 描述: 评估研究进度和完成情况，判断信息收集是否充分，决定继续检索还是开始生成最终网页
- 使用模型: deepseek-chat
- 最大决策次数: 3

### webpage_generator
- 描述: 基于完整的研究成果创建可视化HTML网页，将所有收集的信息整合成最终的展示页面
- 使用模型: deepseek-chat

## 使用的MCP服务器
### memory
- 状态: 启用
- 超时: 60秒

### tavily-mcp
- 状态: 启用
- 超时: 60秒

## 使用的模型
### deepseek-chat
- 基础URL: https://gateway.ai.cloudflare.com/v1/79dc4e1b350a1ac66b63c0f6a9e0c7a6/deepseek/deepseek
- 模型标识符: deepseek-chat
