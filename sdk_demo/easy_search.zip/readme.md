# easy_search
优化循环和全局输出功能的知识探索系统，添加了知识探索摘要节点

## 流程图
```mermaid
graph TD
    Input(["start"]);
    Input(["start"]) --> planning_node["planning_node"];
    planning_node["planning_node"] --> knowledge_exploration_node["knowledge_exploration_node"];
    knowledge_exploration_node["knowledge_exploration_node"] --> exploration_summary_node["exploration_summary_node"];
    exploration_summary_node["exploration_summary_node"] --> decision_node{"decision_node"};
    decision_node{"decision_node"} --> knowledge_exploration_node["knowledge_exploration_node"];
    decision_node{"decision_node"} --> integration_node["integration_node"];
    integration_node["integration_node"] --> answer_node["answer_node"];
    answer_node["answer_node"] --> Output(["end"]);
```

## 节点列表
### planning_node
- 描述: 规划知识探索路径
- 使用模型: deepseek-chat

### knowledge_exploration_node
- 描述: 深入探索知识点
- 使用模型: deepseek-chat
- MCP服务器: bilibili

### exploration_summary_node
- 描述: 总结已探索的知识点和探索进度
- 使用模型: deepseek-chat

### decision_node
- 描述: 判断是否需要继续探索知识点或生成最终答案
- 使用模型: deepseek-chat
- 最大决策次数: 5

### integration_node
- 描述: 整合所有探索的知识
- 使用模型: deepseek-chat

### answer_node
- 描述: 生成最终答案
- 使用模型: deepseek-chat
- 此节点为图的结束节点

## 使用的MCP服务器
### bilibili
- 状态: 启用
- 超时: 60秒
- 自动批准的工具: general_search

## 使用的模型
### deepseek-chat
- 基础URL: https://api.deepseek.com/v1
- 模型标识符: deepseek-chat
