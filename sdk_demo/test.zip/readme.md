# test


## 流程图
```mermaid
graph TD
    Input(["start"]);
    Input(["start"]) --> py{"py"};
    py{"py"} --> speech["speech"];
    py{"py"} --> summary["summary"];
    Input(["start"]) --> py2{"py2"};
    py2{"py2"} --> sum["sum"];
    py2{"py2"} --> speech["speech"];
    py2{"py2"} --> summary["summary"];
    py{"py"} --> sum["sum"];
    sum["sum"] --> Output(["end"]);
    speech["speech"] --> Output(["end"]);
    summary["summary"] --> Output(["end"]);
```

## 节点列表
### py
- 描述: 
- 使用模型: deepseek-chat
- MCP服务器: fetch
- 此节点为图的起始节点

### py2
- 描述: 
- 使用模型: deepseek-chat
- MCP服务器: fetch
- 此节点为图的起始节点

### sum
- 描述: 
- 使用模型: deepseek-chat
- 此节点为图的结束节点

### speech
- 描述: 
- 使用模型: deepseek-chat
- 此节点为图的结束节点

### summary
- 描述: 
- 使用模型: deepseek-chat
- 此节点为图的结束节点

## 使用的MCP服务器
### fetch
- 状态: 启用
- 超时: 60秒
- 自动批准的工具: fetch

## 使用的模型
### deepseek-chat
- 基础URL: https://gateway.ai.cloudflare.com/v1/79dc4e1b350a1ac66b63c0f6a9e0c7a6/deepseek/deepseek
- 模型标识符: deepseek-chat
